# Global Superstore Sales Analysis

## Project Overview
This project explores the Global Superstore retail dataset using Python libraries. It analyses sales, profit, product categories, regions, customer segments, monthly trends, top products, and products with negative total profit.

## Dataset
- **File:** `Global-Superstore.csv`
- **Rows:** 51,290
- **Original columns:** 28
- **Order date range:** 2011-01-01 to 2014-12-31
- **Important fields:** `Order Date`, `Ship Date`, `Order ID`, `Customer ID`, `Segment`, `Region`, `Category`, `Sub-Category`, `Product Name`, `Sales`, `Quantity`, `Discount`, `Profit`, and `Shipping Cost`.

> Use the dataset in accordance with its source license and any applicable sharing restrictions.

## Objectives
- Measure overall sales, profit, quantity, orders, and customers.
- Compare category-wise and region-wise sales and profit.
- Explore monthly sales trends.
- Identify top-selling products and products with negative summed profit.
- Compare customer segments.
- Explore discount and profit patterns to identify areas for further review.

## Tools and Libraries
- Python
- Pandas
- NumPy
- Matplotlib
- Seaborn
- Jupyter Notebook / Google Colab

## Data Cleaning
- Loaded the CSV using `pandas`.
- Removed four mostly empty extra columns from the analysis copy: `Unnamed: 24`, `Unnamed: 25`, `Sales_10%`, and `Unnamed: 27`.
- Converted `Order Date` and `Ship Date` to datetime values.
- Found **0 exact duplicate rows** in the original dataset.
- Kept missing `Postal Code` values as missing instead of guessing replacements.

## Key Results
| Metric | Value |
|---|---:|
| Total sales | 12,642,501.91 |
| Total profit | 1,467,457.29 |
| Quantity sold | 178,312 |
| Unique orders | 25,035 |
| Unique customers | 1,590 |
| Average discount per row | 14.29% |
| Profit as % of sales | 11.61% |

- Highest-sales category: **Technology**
- Highest-profit category: **Technology**
- Highest-sales region: **Central**
- Highest-profit region: **Central**
- Highest-sales customer segment: **Consumer**
- Products with negative summed profit: **678**

## Analysis Performed
1. Data inspection and quality checks
2. Data cleaning
3. Overall sales and profit metrics
4. Category-wise sales and profit analysis
5. Region-wise sales and profit analysis
6. Monthly sales trend
7. Top 10 products by sales
8. Discount and profit analysis
9. Loss-making product analysis
10. Customer segment analysis

## Project Files
Recommended repository structure:

```text
Global-Superstore-Sales-Analysis/
├── Global-Superstore.csv
├── sales_analysis.ipynb
├── requirements.txt
├── README.md
├── outputs/
│   ├── charts/
│   └── tables/
└── report/
    └── Global_Superstore_Sales_Analysis_Report.pdf
```

The PDF report generated for this project is named `Global_Superstore_Sales_Analysis_Report.pdf`.

## Installation
Install dependencies:

```bash
pip install -r requirements.txt
```

## How to Run
1. Download or clone this repository.
2. Install the dependencies listed in `requirements.txt`.
3. Open `sales_analysis.ipynb` in Jupyter Notebook or upload it to Google Colab.
4. Ensure the CSV path in the notebook matches the location of `Global-Superstore.csv`.
5. Run notebook cells in order.

## Recommendations
- Compare sales and profit together when evaluating categories and regions.
- Investigate products with negative total profit using discount, shipping cost, and sub-category.
- Use monthly sales patterns to support inventory and promotion planning.
- Treat discount-profit relationships as correlations, not proof of cause and effect.

## Conclusion
This project demonstrates exploratory data analysis using Python, from data cleaning and aggregation to visualisation and business interpretation. Findings are descriptive of the supplied dataset and should be validated before operational decisions are made.
